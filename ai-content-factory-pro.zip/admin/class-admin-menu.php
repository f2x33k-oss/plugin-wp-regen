<?php
/**
 * Menu d'administration
 *
 * @package AI_Content_Factory_Pro
 */

// Sécurité : Empêcher l'accès direct
if (!defined('ABSPATH')) {
    exit;
}

/**
 * Classe de gestion du menu admin
 */
class AICFP_Admin_Menu {
    
    /**
     * Constructeur
     */
    public function __construct() {
        add_action('admin_menu', array($this, 'add_menu_pages'));
    }
    
    /**
     * Ajouter les pages de menu
     */
    public function add_menu_pages() {
        // Menu principal
        add_menu_page(
            __('AI Content Factory Pro', 'ai-content-factory-pro'),
            __('AI Content Factory', 'ai-content-factory-pro'),
            'manage_options',
            'aicfp-albums-recettes',
            array('AICFP_Albums_Recettes_Page', 'render'),
            'dashicons-admin-generic',
            30
        );
        
        // Sous-menu: Albums Recettes (page par défaut)
        add_submenu_page(
            'aicfp-albums-recettes',
            __('Albums Recettes', 'ai-content-factory-pro'),
            __('Albums Recettes', 'ai-content-factory-pro'),
            'manage_options',
            'aicfp-albums-recettes',
            array('AICFP_Albums_Recettes_Page', 'render')
        );
        
        // Sous-menu: Albums Idées
        add_submenu_page(
            'aicfp-albums-recettes',
            __('Albums Idées', 'ai-content-factory-pro'),
            __('Albums Idées', 'ai-content-factory-pro'),
            'manage_options',
            'aicfp-albums-idees',
            array('AICFP_Albums_Idees_Page', 'render')
        );
        
        // Sous-menu: Vidéos
        add_submenu_page(
            'aicfp-albums-recettes',
            __('Génération de Vidéos IA', 'ai-content-factory-pro'),
            __('Vidéos', 'ai-content-factory-pro'),
            'manage_options',
            'aicfp-videos',
            array('AICFP_Videos_Page', 'render')
        );
        
        // Sous-menu: Instances
        add_submenu_page(
            'aicfp-albums-recettes',
            __('File d\'attente', 'ai-content-factory-pro'),
            __('Instances', 'ai-content-factory-pro'),
            'manage_options',
            'aicfp-instances',
            array('AICFP_Instances_Page', 'render')
        );
        
        // Sous-menu: Réglages
        add_submenu_page(
            'aicfp-albums-recettes',
            __('Réglages', 'ai-content-factory-pro'),
            __('Réglages', 'ai-content-factory-pro'),
            'manage_options',
            'aicfp-settings',
            array('AICFP_Settings_Page', 'render')
        );
    }
}
